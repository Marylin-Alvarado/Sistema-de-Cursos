/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo;

/**
 *
 * @author Marylin
 */
public class Unidad {
    private Float AA;
    private Float TE;
    private Float evaluacion;
    private Float notaUnidad;

    public Float getAA() {
        return AA;
    }

    public void setAA(Float AA) {
        this.AA = AA;
    }

    public Float getTE() {
        return TE;
    }

    public void setTE(Float TE) {
        this.TE = TE;
    }

    public Float getEvaluacion() {
        return evaluacion;
    }

    public void setEvaluacion(Float evaluacion) {
        this.evaluacion = evaluacion;
    }

    public Float getNotaUnidad() {
        return notaUnidad;
    }

    public void setNotaUnidad(Float notaUnidad) {
        this.notaUnidad = notaUnidad;
    }
    
    
}
